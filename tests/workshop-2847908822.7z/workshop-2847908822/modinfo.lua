local lang = locale == "zh"
name = lang and "Performance Pack - 性能优化包" or "Performance Pack"
author = "raccoon"
version = "25-8-20"
description = lang and 
[[
Performance Pack - 性能优化包
]] or 
[[
Performance Pack
]] 
api_version = 10
priority = -9999
dst_compatible = true
dont_starve_compatible = false
shipwrecked_compatible = false
reign_of_giants_compatible = false
all_clients_require_mod = true
client_only_mod = false
server_only_mod = false
server_filter_tags = {"raccoon", "lag", "performance"}

icon_atlas = "modicon.xml"
icon = "modicon.tex"


local function setTitle(str)
    return {
        label = str,
        name = "",
        hover = "",
        options = {{
            description = "",
            data = false
        }},
        default = false
    }
end

local function setConfig(name, title, options, default, desc)
    local _options = {}
    for i=1,#options  do
        _options[i] = {
            description = options[i][1],
            data = options[i][2],
            hover = options[i][3]
        }
    end
    options = _options

    return {
        name = name,
        label = title,
        hover = desc or "",
        options = options,
        default = default
    }
end


local configuration_options_cn = {
    setTitle("性能优化"),
    setConfig("performance_switch","启用性能优化",{{"开启",true},{"关闭",false}},true,"性能优化总开关"),
    setConfig("ai1_switch","生物AI优化",{{"激进",1,"极大降低生物实体所占用运算的资源"},{"平衡",2,"提高性能且不影响游戏体验"},{"关闭",false,"停用优化"}},2,"生物AI的调度模式"),
    setConfig("compatible_switch","安全模式(兼容模式)",{{"开启",true},{"关闭",false}},false,"会影响性能，默认关闭。仅当出现模组冲突时尝试开启，不保证有效"),
    setTitle("拓展功能"),
    setConfig("performance_tips_switch","优化建议与提示",{{"开启",true},{"关闭",false}},true,"根据实时性能表现，提供一些优化建议"),
    setConfig("perf_switch", "显示性能统计信息(TPS & FPS)", {{"开启",true},{"关闭",false}}, true, "显示各项性能参数，用于精准评估服务器和客户端实时性能"),
    setConfig("new_player_join_switch","智能调整房间人数上限",{{"关闭",false},{"开启并公告",2,"当有玩家被阻止进入房间时，服务器将发出公告"},{"静默开启",1,"玩家被阻止进入房间时，没有任何提示"}},false,"根据预设算法动态设置房间最大承载人数，以确保主机流畅度"),
    setTitle("清理和堆叠"),
    setConfig("clean_day","自动清理",{{"关闭",false},{"5天",5},{"10天",10},{"20天",20},{"25天",25},{"50天",50},{"100天",100},{"关闭",false}},25,"自动清理地面上的垃圾"),
    setConfig("stack_dis","自动堆叠",{{"关闭",false},{"半径1个地皮",4},{"半径2.5个地皮",10},{"半径4个地皮",16},{"半径8个地皮",32},{"关闭",false}},10,"自动将掉落的战利品或材料堆叠在一起"),
   }


local configuration_options_en = {
    setTitle("Performance Optimization"),
    setConfig("performance_switch","Enable Optimization",{{"Enable",true},{"Disable",false}},true,"Master switch for performance optimization"),
    setConfig("ai1_switch","AI Optimization",{{"Aggressive",1,"Significantly reduce computational resources used by creature-type entities"},{"Balanced",2,"Mild optimization with almost no impact on gameplay"},{"Disable",false,"Turn off AI optimization"}},2,"Optimization mode for creature AI"),
    setConfig("compatible_switch","Safe Mode(Compatibility Mode)",{{"Enable",true},{"Disable",false}},false,"Reduces performance. Attempts to fix mod conflicts, but offers no guarantee."),
    setTitle("Advanced Features"),
    setConfig("performance_tips_switch","Optimization Suggestions",{{"Enable",true},{"Disable",false}},true,"Provide some optimization suggestions based on real-time performance"),
    setConfig("perf_switch", "Show (TPS & FPS)", {{"Enable",true},{"Disable",false}}, true, "Allows players to access performance data for accurate real-time server/client assessment"),
    setConfig("new_player_join_switch","Dynamic Room Capacity Adjustment",{{"Disable",false},{"Enable",1},{"Enable and Announce",2,"When a player is prevented from joining, the server will announce it"}},false,"When poor server performance is detected, automatically prevent new players from joining to avoid further lag"),
    setTitle("Cleaning and Stacking"),
    setConfig("clean_day","Auto Clean",{{"Disable",false},{"5 Days",5},{"10 Days",10},{"20 Days",20},{"25 Days",25},{"50 Days",50},{"100 Days",100},{"Disable",false}},25,"New cleanup rule: Each cleanup records the location of clutter; if the position remains unchanged, it will be cleaned. Additionally, clutter near buildings will not be cleaned"),
    setConfig("stack_dis","Auto Stack",{{"Disable",false},{"Radius 1 tile",4},{"Radius 2.5 tiles",10},{"Radius 4 tiles",16},{"Radius 8 tiles",32},{"Disable",false}},10,"Automatically stack dropped loot or chopped materials together"),
  }


configuration_options = lang and configuration_options_cn or configuration_options_en