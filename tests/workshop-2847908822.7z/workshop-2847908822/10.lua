local oi0Hd0F = {
	[(95 + -24)] = "\109\111\118"
		.. ("\99\95\103\110\105"):reverse()
		.. ("\107\97\101\104"):reverse()
		.. ("\103\111\108\95"):reverse(),
	[(-15 + 18)] = false,
	[(-99 + 130)] = nil,
	[(60 + -44)] = ("\114\113\115"):reverse() .. ("\116"):reverse(),
	[(-99 + 166)] = false,
	[(-36 + 41)] = "\109\111\118\105" .. "\110\103\95\99\104\101" .. "\97" .. "\107\95\108\111\103",
	[(29 + -22)] = "\105\115" .. "\109\111\118\101\105\110" .. "\103",
	[(-67 + 121)] = nil,
	[(45 + 30)] = "\108\66\110",
	[(0 + 24)] = "\122",
	[(74 + 9)] = (-10 + 18),
	[(-33 + 59)] = "\112\108\97" .. ("\101\121"):reverse() .. "\114",
	[(-37 + 50)] = "\109" .. ("\110\105\118\111"):reverse() .. string.char((27 + 76), (80 + 15)) .. string.char(
		(0 + 99),
		(-19 + 123),
		(36 + 65),
		(99 + -2)
	) .. "\107\95\108" .. ("\103\111"):reverse(),
	[(-12 + 94)] = "\112\103" .. "\73" .. ("\115\107\68"):reverse(),
	[(99 + -63)] = string.char((99 + -20), (15 + 95), (-6 + 75), (-3 + 113), (-91 + 207))
		.. string.char((100 + 5), (-35 + 151), (-18 + 139), (-22 + 105), (-35 + 143))
		.. "\101"
		.. "\101\112",
	[(28 + -20)] = false,
	[(-56 + 77)] = "\122",
	[(-75 + 98)] = string.char((-54 + 176)),
	[(-59 + 110)] = nil,
	[(24 + 63)] = ("\53\109\53\68"):reverse() .. "\117" .. "\121",
	[(-44 + 48)] = ("\101\110"):reverse() .. "\120\116",
	[(85 + -47)] = ("\103\110\105\118\111\109"):reverse()
		.. "\95"
		.. "\99\104\101\97\107"
		.. "\95\116"
		.. "\97\115\107",
	[(23 + 46)] = ("\101\114"):reverse() .. "\109\111\118" .. ("\101"):reverse(),
	[(-41 + 47)] = "\109"
		.. "\111"
		.. string.char((-29 + 147), (25 + 80), (7 + 103), (81 + 22))
		.. "\95\99\104\101"
		.. string.char((87 + 10), (-39 + 146), (-52 + 147), (-67 + 175), (11 + 100))
		.. "\103",
	[(100 + -83)] = "\120",
	[(-20 + 86)] = "\109\111\118"
		.. ("\95\103\110\105"):reverse()
		.. "\99\104"
		.. ("\111\108\95\107\97\101"):reverse()
		.. "\103",
	[(-59 + 127)] = ("\103\110\105\118\111\109"):reverse()
		.. string.char((78 + 17), (-36 + 135), (-87 + 191), (-94 + 195), (-40 + 137))
		.. "\107\95\108\111\103",
	[(-62 + 115)] = ("\111\112\109\111\99"):reverse() .. ("\110"):reverse() .. "\101\110\116\115",
	[(36 + 24)] = "\109\111\118\105\110"
		.. ("\104\99\95\103"):reverse()
		.. string.char((43 + 58))
		.. "\97\107\95\108\111"
		.. "\103",
	[(-32 + 71)] = "\109\111"
		.. ("\105\118"):reverse()
		.. "\110\103\95\99\104\101"
		.. "\97\107\95"
		.. ("\107\115\97\116"):reverse(),
	[(23 + 9)] = "\115\103",
	[(37 + -7)] = "\108\111" .. "\99\111" .. "\109\111" .. "\116\111" .. ("\114"):reverse(),
	[(-79 + 108)] = "\99" .. "\111\109\112\111\110" .. ("\115\116\110\101"):reverse(),
	[(89 + -47)] = nil,
	[(82 + -42)] = nil,
	[(-64 + 145)] = "\111\97" .. string.char((98 + 6), (7 + 114)),
	[(53 + -16)] = string.char((5 + 74), (-82 + 192), (-84 + 153))
		.. string.char((-66 + 176))
		.. string.char((56 + 60), (-78 + 183), (30 + 86), (91 + 30))
		.. "\83\108\101"
		.. string.char((-50 + 151), (-4 + 116)),
	[(-61 + 102)] = "\109\111\118\105"
		.. "\110\103"
		.. ("\99\95"):reverse()
		.. string.char((-41 + 145), (-19 + 120))
		.. "\97"
		.. ("\103\111\108\95\107"):reverse(),
	[(-45 + 121)] = string.char((-11 + 112), (-10 + 79)) .. string.char((96 + 15), (-18 + 67)),
	[(22 + -3)] = "\120",
	[(2 + 48)] = "\109\111\118"
		.. "\105\110\103\95\99"
		.. "\104\101\97"
		.. ("\97\116\95\107"):reverse()
		.. ("\115"):reverse()
		.. ("\107"):reverse(),
	[(19 + 28)] = false,
	[(-54 + 117)] = string.char((62 + 47), (-80 + 191), (-61 + 179))
		.. string.char((-23 + 128), (-10 + 120), (-43 + 146), (9 + 86), (-62 + 161), (49 + 55))
		.. ("\111\108\95\107\97\101"):reverse()
		.. ("\103"):reverse(),
	[(-93 + 128)] = string.char((-61 + 162), (-94 + 206), (1 + 104)) .. "\99",
	[(-91 + 100)] = true,
	[(59 + -7)] = string.char((95 + 14), (-45 + 156))
		.. string.char((-94 + 212), (4 + 101))
		.. ("\110"):reverse()
		.. string.char((14 + 89))
		.. "\95"
		.. "\99\104\101\97\107\95"
		.. ("\107\115\97\116"):reverse(),
	[(-25 + 36)] = ("\105\118\111\109"):reverse()
		.. "\110\103\95\99\104"
		.. string.char((43 + 58), (66 + 31), (-50 + 157), (6 + 89), (75 + 33), (-32 + 143))
		.. ("\103"):reverse(),
	[(-67 + 122)] = "\99\111\109\112" .. string.char((2 + 109)) .. "\110\101\110\116\115",
	[(-54 + 79)] = string.char((-31 + 140), (-82 + 179)) .. string.char((-62 + 182)),
	[(34 + 12)] = true,
	[(98 + -36)] = ("\105"):reverse() .. "\110\115" .. "\101\114\116",
	[(-53 + 126)] = "\114\97" .. "\110\100" .. "\111\109",
	[(-22 + 37)] = ("\116\97\109"):reverse() .. "\104",
	[(36 + -26)] = (99 + -99),
	[(-96 + 145)] = "\79" .. "\110\69\110\116\105" .. "\116" .. "\121\87\97\107\101",
	[(33 + 25)] = "\115\103",
	[(65 + 23)] = "\57" .. "\98\53\82",
	[(29 + 48)] = "\49\79\65" .. "\106\105",
	[(-78 + 106)] = nil,
	[(35 + -15)] = "\120",
	[(-70 + 127)] = nil,
	[(-75 + 119)] = "\109\111\111" .. ("\110"):reverse() .. string.char((41 + 57), (54 + 43), (-65 + 180), (77 + 24)),
	[(-21 + 48)] = "\99\111\109\112" .. ("\101\110\111"):reverse() .. ("\115\116\110"):reverse(),
	[(18 + 4)] = string.char((-89 + 211)),
	[(-9 + 42)] = nil,
	[(-42 + 76)] = "\108\97\114" .. ("\97\101\114\99\101\103"):reverse() .. "\116\117\114\101",
	[(-17 + 76)] = nil,
	[(62 + 16)] = (13 + 40),
	[(5 + 38)] = (64 + -52),
	[(82 + -70)] = string.char((24 + 88)) .. string.char((-66 + 177)) .. "\115",
	[(93 + -7)] = (26 + 49),
	[(-63 + 147)] = string.char((-24 + 79), (-3 + 113)) .. "\113\81",
	[(8 + 40)] = "\79\110\69\110\116\105" .. "\116\121\87\97\107" .. "\101",
	[(-58 + 122)] = true,
	[(94 + -24)] = ("\105\118\111\109"):reverse()
		.. "\110\103\95"
		.. "\99\104\101"
		.. ("\97"):reverse()
		.. ("\103\111\108\95\107"):reverse(),
	[(73 + -55)] = "\120",
	[(1 + 13)] = string.char((20 + 92), (-66 + 177), (28 + 87)),
	[(95 + -30)] = "\105" .. ("\110"):reverse() .. "\115\101\114\116",
	[(30 + 15)] = (99 + -98),
	[(92 + -7)] = "\79" .. string.char((98 + 19), (73 + 12)),
	[(60 + -59)] = (65 + -62),
	[(81 + -2)] = ("\72"):reverse() .. "\71\74\98\65",
	[(20 + -18)] = "\109\111" .. "\118\105" .. string.char((-77 + 187), (-45 + 148)),
	[(-76 + 148)] = 0.05,
	[(-45 + 106)] = "\109\111\118\105\110\103"
		.. string.char((-21 + 116))
		.. string.char((2 + 97), (-25 + 129), (-50 + 151), (-36 + 133))
		.. "\107\95\108\111\103",
	[(93 + -13)] = "\53\104" .. string.char((-3 + 73), (45 + 6)),
	[(-94 + 168)] = string.char((-83 + 154)) .. "\122\76\81",
	[(-43 + 99)] = "\108\111" .. "\99\111\109\111" .. ("\114\111\116"):reverse(),
}
local j_NWWt = GLOBAL
local hpETTai = oi0Hd0F[(49 + -48)]
local w2PlPr = oi0Hd0F[(24 + -23)]
local function QnUfUjK(oylwxug)
	return oylwxug.sg:HasStateTag(oi0Hd0F[(70 + -68)]) or oi0Hd0F[(49 + -46)]
end
local function aqYR9PK(yDP3oy4H)
	if not j_NWWt[oi0Hd0F[(-50 + 54)]](yDP3oy4H[oi0Hd0F[(-13 + 18)]]) then
		return
	end
	for RejDM6Bt, E8tmkm in pairs(yDP3oy4H[oi0Hd0F[(-83 + 89)]]) do
		if not E8tmkm[oi0Hd0F[(61 + -54)]] then
			return oi0Hd0F[(47 + -39)]
		end
	end
	return oi0Hd0F[(73 + -64)]
end
local function mZByhlBg(AmUOM9)
	local ED56eC = oi0Hd0F[(30 + -20)]
	for GVact8, J_cv30DQ in ipairs(AmUOM9[oi0Hd0F[(5 + 6)]]) do
		local l3J8pge = J_cv30DQ[oi0Hd0F[(-97 + 109)]]
		for Fy8kibb, CuDMNHv in ipairs(AmUOM9[oi0Hd0F[(23 + -10)]]) do
			if GVact8 ~= Fy8kibb then
				local gCUIXS1e = CuDMNHv[oi0Hd0F[(-69 + 83)]]
				local Op3ej6 = j_NWWt[oi0Hd0F[(-61 + 76)]][oi0Hd0F[(63 + -47)]](
					(l3J8pge[oi0Hd0F[(-68 + 85)]] - gCUIXS1e[oi0Hd0F[(40 + -22)]])
							* (l3J8pge[oi0Hd0F[(-27 + 46)]] - gCUIXS1e[oi0Hd0F[(69 + -49)]])
						+ (l3J8pge[oi0Hd0F[(-41 + 62)]] - gCUIXS1e[oi0Hd0F[(-16 + 38)]])
							* (l3J8pge[oi0Hd0F[(-11 + 34)]] - gCUIXS1e[oi0Hd0F[(42 + -18)]])
				)
				ED56eC = math[oi0Hd0F[(79 + -54)]](Op3ej6, ED56eC)
			end
		end
	end
	return ED56eC
end
AddPrefabPostInitAny(function(bXvgk0d)
	if bXvgk0d:HasTag(oi0Hd0F[(59 + -33)]) then
		return
	elseif
		bXvgk0d[oi0Hd0F[(-97 + 124)]] == oi0Hd0F[(57 + -29)]
		or bXvgk0d[oi0Hd0F[(-73 + 102)]][oi0Hd0F[(-65 + 95)]] == oi0Hd0F[(-28 + 59)]
	then
		return
	elseif bXvgk0d[oi0Hd0F[(91 + -59)]] == oi0Hd0F[(-2 + 35)] then
		return
	elseif bXvgk0d:HasTag(oi0Hd0F[(65 + -31)]) then
		return
	elseif bXvgk0d:HasTag(oi0Hd0F[(-36 + 71)]) then
		return
	end
	local mLZsv5tf = bXvgk0d[oi0Hd0F[(25 + 11)]]
	bXvgk0d[oi0Hd0F[(-27 + 64)]] = function(...)
		if bXvgk0d[oi0Hd0F[(2 + 36)]] then
			bXvgk0d.moving_cheak_task:Cancel()
			bXvgk0d[oi0Hd0F[(97 + -58)]] = oi0Hd0F[(13 + 27)]
			bXvgk0d[oi0Hd0F[(-76 + 117)]] = oi0Hd0F[(87 + -45)]
		end
		if mLZsv5tf then
			return mLZsv5tf(...)
		end
	end
	local function V0GF6P(aTLKxpc7)
		local Frgb_YQB, WXl6jf_2, WVVs08v = aTLKxpc7.Transform:GetWorldPosition()
		local uARslvV =
			j_NWWt.TheSim:FindEntities(Frgb_YQB, WXl6jf_2, WVVs08v, oi0Hd0F[(-78 + 121)], { oi0Hd0F[(-44 + 88)] })
		if uARslvV and #uARslvV >= oi0Hd0F[(-60 + 105)] then
			return oi0Hd0F[(51 + -5)]
		end
		return oi0Hd0F[(-51 + 98)]
	end
	local h7LGTN0 = bXvgk0d[oi0Hd0F[(28 + 20)]]
	bXvgk0d[oi0Hd0F[(93 + -44)]] = function(...)
		if bXvgk0d[oi0Hd0F[(47 + 3)]] == oi0Hd0F[(-87 + 138)] then
			bXvgk0d[oi0Hd0F[(-26 + 78)]] = bXvgk0d:DoPeriodicTask(w2PlPr, function(MF6Tu3)
				if
					MF6Tu3[oi0Hd0F[(45 + 8)]] == oi0Hd0F[(58 + -4)]
					or MF6Tu3[oi0Hd0F[(-38 + 93)]][oi0Hd0F[(68 + -12)]] == oi0Hd0F[(-100 + 157)]
				then
					return
				elseif MF6Tu3[oi0Hd0F[(70 + -12)]] == oi0Hd0F[(86 + -27)] then
					return
				end
				MF6Tu3[oi0Hd0F[(9 + 51)]] = MF6Tu3[oi0Hd0F[(85 + -24)]] or {}
				local DZ0z2jb = QnUfUjK(MF6Tu3)
				if DZ0z2jb then
					local _a790v4W, SbQTwO, dhrI2PK = MF6Tu3.Transform:GetWorldPosition()
					table[oi0Hd0F[(0 + 62)]](
						MF6Tu3[oi0Hd0F[(-99 + 162)]],
						{ ismoveing = oi0Hd0F[(59 + 5)], pos = { x = _a790v4W, y = SbQTwO, z = dhrI2PK } }
					)
				else
					table[oi0Hd0F[(-39 + 104)]](
						MF6Tu3[oi0Hd0F[(-77 + 143)]],
						{ ismoveing = oi0Hd0F[(-6 + 73)], pos = {} }
					)
				end
				if #MF6Tu3[oi0Hd0F[(-54 + 122)]] > hpETTai then
					table[oi0Hd0F[(69 + 0)]](MF6Tu3[oi0Hd0F[(-12 + 82)]], oi0Hd0F[(63 + -18)])
				end
				if
					DZ0z2jb
					and #MF6Tu3[oi0Hd0F[(-43 + 114)]] >= hpETTai
					and aqYR9PK(MF6Tu3)
					and mZByhlBg(MF6Tu3) < oi0Hd0F[(-55 + 127)]
					and not V0GF6P(MF6Tu3)
				then
					MF6Tu3.components.locomotor:Stop()
				end
			end, math[oi0Hd0F[(-34 + 107)]]() * w2PlPr)
		end
		if h7LGTN0 then
			return h7LGTN0(...)
		end
	end
end)
