local V2D8y3l = {
	[(16 + 25)] = ("\67\83"):reverse(),
	[(-63 + 74)] = string.char((35 + 81)) .. ("\101\112\121"):reverse(),
	[(-84 + 132)] = "\102\111\114\109" .. "\97" .. "\116",
	[(15 + 5)] = "\116\112\115" .. string.char((19 + 65), (99 + 2), (-40 + 160)) .. "\116",
	[(73 + -43)] = string.char((-71 + 187), (-60 + 181), (-60 + 172)) .. string.char((70 + 31)),
	[(-87 + 92)] = string.char((-15 + 127), (-76 + 177), (55 + 59), (-49 + 151), (56 + 55))
		.. "\114\109"
		.. "\97\110\99\101\95"
		.. "\112\97\99"
		.. "\107\95\99\111\110"
		.. "\102\105\103",
	[(-88 + 92)] = "\72" .. "\73\68" .. string.char((99 + -30)),
	[(-23 + 32)] = "\109" .. "\115\112\116",
	[(44 + 25)] = "\104\48\111" .. "\53\104",
	[(-80 + 154)] = string.char((7 + 111), (-38 + 115)) .. ("\97\52"):reverse(),
	[(-17 + 87)] = "\84\80" .. "\84\77" .. "\65\50",
	[(80 + -27)] = "\70\80\83"
		.. "\58"
		.. string.char((45 + -8), (-66 + 181), (69 + -37), (64 + 16), (-82 + 155))
		.. "\78\71\58"
		.. "\37"
		.. string.char((-44 + 159), (-5 + 114), (66 + 49)),
	[(38 + 2)] = "\116\121" .. "\112\101",
	[(58 + 18)] = (-85 + 113),
	[(-79 + 93)] = nil,
	[(24 + 41)] = false,
	[(61 + -1)] = false,
	[(81 + -59)] = string.char((49 + 67), (-61 + 173)) .. "\115\84" .. "\101" .. "\120" .. string.char((-58 + 174)),
	[(72 + -9)] = nil,
	[(13 + 12)] = (76 + -71),
	[(-13 + 60)] = string.char((-79 + 162)),
	[(-2 + 35)] = "\116\121\112" .. ("\101"):reverse(),
	[(32 + 19)] = ("\67"):reverse(),
	[(53 + 19)] = string.char((4 + 109), (-86 + 162), (-16 + 105)) .. "\51\54",
	[(29 + -27)] = "\83",
	[(41 + -31)] = (91 + -91),
	[(-63 + 106)] = "\84\80\83"
		.. ("\32\115\37\58"):reverse()
		.. "\76\85\65\95\77\83"
		.. "\80\84\58\37"
		.. ("\70\10\115\109\115"):reverse()
		.. "\80\83"
		.. ("\37\58"):reverse()
		.. string.char((60 + 55), (74 + -42), (-41 + 121), (33 + 40))
		.. string.char((-22 + 100))
		.. ("\115\37\58\71"):reverse()
		.. "\109\115",
	[(-70 + 97)] = nil,
	[(-51 + 95)] = string.char((-69 + 168)) .. "\101\105\108",
	[(72 + -65)] = "\116\112\115",
	[(92 + -47)] = "\99\101\105" .. "\108",
	[(61 + 5)] = (98 + -9),
	[(-29 + 78)] = "\84\80\83\58\37\115"
		.. string.char((-59 + 91), (-93 + 169), (-32 + 117), (-55 + 120), (58 + 37), (34 + 43))
		.. "\83\80\84\58\37"
		.. "\115\109\115",
	[(-69 + 136)] = string.char((71 + -17), (0 + 111), (10 + 74)),
	[(-13 + 88)] = (-67 + 154),
	[(-39 + 78)] = "",
	[(71 + -21)] = "\116\121" .. string.char((87 + 25), (20 + 81)),
	[(-22 + 81)] = string.char((51 + 16), (-16 + 124), (0 + 105), (46 + 53), (87 + 20))
		.. "\32\32\32\32\32"
		.. ("\32"):reverse(),
	[(24 + 49)] = (32 + -11),
	[(82 + -30)] = ("\102"):reverse() .. ("\114\111"):reverse() .. string.char((30 + 79), (77 + 20), (96 + 20)),
	[(29 + -1)] = "\116\112\115\95" .. "\116\121\112" .. "\101",
	[(-79 + 117)] = ("\115\109"):reverse() .. string.char((-34 + 146), (41 + 75)),
	[(40 + -28)] = (47 + -46),
	[(-86 + 87)] = "\83" .. "\67",
	[(18 + 14)] = ("\100\112\85"):reverse()
		.. ("\101\83\101\116\97"):reverse()
		.. string.char((68 + 46), (27 + 91), (70 + 31), (57 + 57), (91 + -23))
		.. string.char((54 + 43), (64 + 52), (-22 + 119)),
	[(-28 + 86)] = 0.25,
	[(-51 + 66)] = "\116" .. string.char((82 + 30), (83 + 32), (91 + -7), (-38 + 139), (-26 + 146)) .. string.char(
		(-16 + 132)
	),
	[(-60 + 94)] = "\116" .. string.char((-11 + 132), (-65 + 177), (-96 + 197)),
	[(-15 + 76)] = nil,
	[(-95 + 150)] = "\99\101" .. "\105\108",
	[(88 + -70)] = 0.6,
	[(-3 + 27)] = (29 + -27),
	[(5 + 30)] = ("\116"):reverse() .. string.char((11 + 110), (38 + 74), (-82 + 183)),
	[(46 + -33)] = string.char((-49 + 153), (21 + 84), (-68 + 168), (-11 + 112)) .. "\95\116" .. string.char(
		(-19 + 124),
		(21 + 91)
	) .. "\95\116\97\115\107",
	[(65 + -23)] = string.char((-43 + 145), (-48 + 159)) .. "\114\109" .. "\97\116",
	[(57 + -20)] = "\116\112\115",
	[(95 + -92)] = string.char((-80 + 147)),
	[(-98 + 160)] = ("\112\116"):reverse() .. "\115\109\111\110\105" .. "\116\111\114" .. ("\115\112\116\95"):reverse(),
	[(-88 + 166)] = string.char((74 + 39)) .. "\112\73",
	[(-53 + 79)] = "\76\111\97\100\83" .. ("\101\118\114\101"):reverse() .. "\114\68\97\116\97",
	[(66 + 2)] = (-72 + 138),
	[(-93 + 101)] = (34 + 26),
	[(72 + 5)] = "\48\113\66",
	[(-97 + 143)] = string.char((-6 + 122)) .. ("\121"):reverse() .. "\112\101",
	[(27 + 53)] = (30 + 58),
	[(-61 + 82)] = "\83\101\116\84" .. "\101\120" .. "\116",
	[(31 + -14)] = string.char((38 + 60), (-17 + 125), (-36 + 133))
		.. string.char((92 + 18), (-37 + 144))
		.. string.char((44 + 2))
		.. "\116\101\120",
	[(63 + -40)] = string.char((13 + 70), (-86 + 187), (70 + 46))
		.. "\84"
		.. string.char((30 + 71), (42 + 78), (72 + 44)),
	[(66 + -47)] = (-14 + 34),
	[(-81 + 87)] = ("\95"):reverse() .. "\99" .. "\116\111\114",
	[(10 + 26)] = string.char((87 + 29), (-97 + 218)) .. "\112\101",
	[(33 + 23)] = ("\116"):reverse() .. ("\101\112\121"):reverse(),
	[(-5 + 84)] = "\77\86\77\53" .. string.char((-21 + 106)),
	[(80 + -26)] = string.char((-22 + 121), (30 + 71), (-44 + 149)) .. "\108",
	[(-59 + 116)] = "\72\73" .. "\68\69",
	[(-58 + 89)] = ("\115\112\116"):reverse() .. ("\116\95"):reverse() .. "\121\112\101",
	[(-14 + 43)] = nil,
	[(78 + -14)] = "",
	[(-69 + 85)] = "\105\109"
		.. ("\47\115\101\103\97"):reverse()
		.. string.char((8 + 109), (-86 + 191), (1 + 45), (26 + 94), (97 + 12))
		.. "\108",
	[(59 + 12)] = ("\100\66\105"):reverse() .. string.char((-19 + 86)) .. "\68",
}
local ftvncAj = require("widgets/widget")
local IH4sEXQW = require("widgets/text")
local NiPJyB = require("widgets/imagebutton")
local kOLUzBPI = { V2D8y3l[(-74 + 75)], V2D8y3l[(96 + -94)], V2D8y3l[(-84 + 87)], V2D8y3l[(19 + -15)] }
local CRl9BB = V2D8y3l[(-71 + 76)]
local MK6GwHk = Class(ftvncAj, function(wLPKCw0)
	ftvncAj[V2D8y3l[(30 + -24)]](wLPKCw0)
	wLPKCw0[V2D8y3l[(-7 + 14)]] = V2D8y3l[(48 + -40)]
	wLPKCw0[V2D8y3l[(17 + -8)]] = V2D8y3l[(51 + -41)]
	wLPKCw0[V2D8y3l[(41 + -30)]] = kOLUzBPI[V2D8y3l[(-68 + 80)]]
	wLPKCw0[V2D8y3l[(-54 + 67)]] = V2D8y3l[(-2 + 16)]
	wLPKCw0[V2D8y3l[(66 + -51)]] = wLPKCw0:AddChild(NiPJyB(V2D8y3l[(30 + -14)], V2D8y3l[(3 + 14)]))
	wLPKCw0.tpsText:SetTextColour(V2D8y3l[(81 + -69)], V2D8y3l[(89 + -77)], V2D8y3l[(-36 + 48)], V2D8y3l[(-50 + 62)])
	wLPKCw0.tpsText:SetTextFocusColour(
		V2D8y3l[(-9 + 21)],
		V2D8y3l[(-30 + 42)],
		V2D8y3l[(94 + -82)],
		V2D8y3l[(44 + -26)]
	)
	wLPKCw0.tpsText:SetFont(DEFAULTFONT)
	wLPKCw0.tpsText:SetTextSize(V2D8y3l[(36 + -17)])
	wLPKCw0.tpsText:SetOnClick(function()
		wLPKCw0:ChangeShowType()
	end)
	wLPKCw0.tpsText:SetVAnchor(ANCHOR_TOP)
	wLPKCw0.tpsText:SetHAnchor(ANCHOR_LEFT)
	wLPKCw0.tpsText.text:SetHAlign(ANCHOR_LEFT)
	local KwLGb0y = wLPKCw0[V2D8y3l[(54 + -34)]][V2D8y3l[(-47 + 68)]]
	wLPKCw0[V2D8y3l[(-83 + 105)]][V2D8y3l[(95 + -72)]] = function(sdwU_PU, ...)
		KwLGb0y(sdwU_PU, ...)
		local auiqbiX, al5dk8 = sdwU_PU.text:GetRegionSize()
		sdwU_PU:SetPosition(
			auiqbiX / V2D8y3l[(3 + 21)] + V2D8y3l[(82 + -57)],
			-al5dk8 / V2D8y3l[(17 + 7)] - V2D8y3l[(18 + 7)]
		)
		sdwU_PU.image:SetSize(sdwU_PU.text:GetRegionSize())
	end
	wLPKCw0:MoveToFront()
	wLPKCw0:LoadType()
	wLPKCw0:StartUpdating()
end)
function MK6GwHk:LoadType()
	local o7f5uN3 = PPPersist[V2D8y3l[(-48 + 74)]](CRl9BB)
	if o7f5uN3 == V2D8y3l[(63 + -36)] or o7f5uN3[V2D8y3l[(-64 + 92)]] == V2D8y3l[(-69 + 98)] then
		return
	end
	self[V2D8y3l[(-17 + 47)]] = o7f5uN3[V2D8y3l[(-81 + 112)]]
end
function MK6GwHk:SaveType()
	PPPersist[V2D8y3l[(17 + 15)]](CRl9BB, { tps_type = self[V2D8y3l[(-70 + 103)]] })
end
function MK6GwHk:ChangeShowType()
	local XmpjiYwJ = V2D8y3l[(-42 + 54)]
	for PMffSAyX, dJFdC_sR in ipairs(kOLUzBPI) do
		if dJFdC_sR == self[V2D8y3l[(-39 + 73)]] then
			XmpjiYwJ = PMffSAyX
			break
		end
	end
	XmpjiYwJ = XmpjiYwJ + V2D8y3l[(-26 + 38)]
	if XmpjiYwJ > #kOLUzBPI then
		self[V2D8y3l[(62 + -27)]] = kOLUzBPI[V2D8y3l[(26 + -14)]]
	else
		self[V2D8y3l[(-45 + 81)]] = kOLUzBPI[XmpjiYwJ]
	end
	self.tpsText:SetTextColour(V2D8y3l[(-35 + 47)], V2D8y3l[(84 + -72)], V2D8y3l[(11 + 1)], V2D8y3l[(-75 + 87)])
	self:MoveToFront()
	self:SaveType()
end
function MK6GwHk:SetTps(dl01hna, qwKmJq8i)
	self[V2D8y3l[(-97 + 134)]] = dl01hna
	self[V2D8y3l[(92 + -54)]] = qwKmJq8i
	local fybrG4XD = V2D8y3l[(-11 + 50)]
	if self[V2D8y3l[(91 + -51)]] == V2D8y3l[(33 + 8)] then
		fybrG4XD = string[V2D8y3l[(56 + -14)]](
			V2D8y3l[(-59 + 102)],
			dl01hna,
			qwKmJq8i,
			math[V2D8y3l[(-24 + 68)]](TheSim:GetFPS()),
			math[V2D8y3l[(-38 + 83)]](TheNet:GetPing())
		)
	elseif self[V2D8y3l[(-14 + 60)]] == V2D8y3l[(46 + 1)] then
		fybrG4XD = string[V2D8y3l[(50 + -2)]](V2D8y3l[(-62 + 111)], dl01hna, qwKmJq8i)
	elseif self[V2D8y3l[(56 + -6)]] == V2D8y3l[(-75 + 126)] then
		fybrG4XD = string[V2D8y3l[(35 + 17)]](
			V2D8y3l[(55 + -2)],
			math[V2D8y3l[(-71 + 125)]](TheSim:GetFPS()),
			math[V2D8y3l[(-56 + 111)]](TheNet:GetPing())
		)
	elseif self[V2D8y3l[(34 + 22)]] == V2D8y3l[(30 + 27)] then
		self.tpsText:SetTextColour(V2D8y3l[(79 + -67)], V2D8y3l[(-10 + 22)], V2D8y3l[(71 + -59)], V2D8y3l[(-83 + 141)])
		fybrG4XD = V2D8y3l[(1 + 58)]
	end
	self.tpsText:SetText(fybrG4XD, V2D8y3l[(-6 + 66)], { -V2D8y3l[(-79 + 91)], -V2D8y3l[(-44 + 56)] })
end
function MK6GwHk:OnUpdate(Oy9FNENN)
	if ThePlayer == V2D8y3l[(-25 + 86)] or ThePlayer[V2D8y3l[(-75 + 137)]] == V2D8y3l[(43 + 20)] then
		self.tpsText:SetText(V2D8y3l[(-18 + 82)], V2D8y3l[(-83 + 148)], { -V2D8y3l[(22 + -10)], -V2D8y3l[(-87 + 99)] })
		return
	end
	local xYpPLmb = ThePlayer.tpsmonitor_tps:value()
	local hkVWg8m = ThePlayer.tpsmonitor_mspt:value()
	if xYpPLmb and hkVWg8m then
		self:SetTps(xYpPLmb, hkVWg8m)
	end
end
return MK6GwHk
