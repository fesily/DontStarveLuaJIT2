local uVVtT7qK = {
	[(16 + 26)] = (49 + -29),
	[(60 + -1)] = (-32 + 101),
	[(-73 + 78)] = (-84 + 85),
	[(-19 + 23)] = (-8 + 8),
	[(35 + 17)] = (27 + 25),
	[(67 + -43)] = "\80\80\80\101\114" .. ("\115\105\115"):reverse() .. ("\116"):reverse(),
	[(-78 + 133)] = (95 + -85),
	[(38 + 20)] = ("\78\55\48\67"):reverse() .. ("\74"):reverse() .. string.char((-14 + 129)),
	[(36 + 21)] = "\104\112\108" .. ("\88"):reverse() .. "\52\74",
	[(64 + -56)] = (-36 + 67),
	[(-30 + 56)] = "\80\101\114\115\105" .. "\115\116" .. "\101\110\99\101",
	[(-90 + 129)] = ("\101\80"):reverse()
		.. string.char((-94 + 208))
		.. ("\115\105\115"):reverse()
		.. "\116\101"
		.. string.char((-8 + 118), (-12 + 111), (7 + 94)),
	[(44 + -12)] = "\68\97\116\97\68\117" .. "\109\112\101" .. "\114",
	[(33 + -27)] = string.char((2 + 113)) .. "\116\114" .. ("\103\110\105"):reverse(),
	[(-21 + 56)] = string.char((-15 + 95), (-44 + 145)) .. ("\105\115\114"):reverse() .. "\115\116\101\110\99\101",
	[(17 + -7)] = (57 + -25),
	[(88 + -32)] = "\107" .. "\86\112",
	[(-81 + 117)] = string.char((80 + 5))
		.. string.char((34 + 78), (-18 + 118))
		.. "\97\116"
		.. string.char((6 + 95), (-74 + 157), (-19 + 120), (14 + 100), (59 + 59))
		.. string.char((34 + 67), (69 + 45))
		.. string.char((-91 + 159), (76 + 21), (4 + 112), (97 - 0)),
	[(-37 + 88)] = "\53\121" .. string.char((94 + -8), (23 + 92)) .. "\121\80",
	[(-41 + 44)] = nil,
	[(77 + -50)] = string.char((-55 + 131), (-87 + 198)) .. "\97\100\83\101\114\118" .. "\101\114\68\97\116\97",
	[(69 + -15)] = string.char((37 + 69), (-28 + 78)) .. ("\78"):reverse() .. ("\107\109"):reverse(),
	[(25 + 35)] = "\51\82\66",
	[(72 + -29)] = 0.1,
	[(-46 + 63)] = string.char((24 + 34)),
	[(84 + -36)] = (-15 + 20015),
	[(-21 + 34)] = "\102\108" .. "\111\111\114",
	[(11 + 42)] = string.char((7 + 67), (73 + 4), (-18 + 84), (87 + -35)) .. ("\121"):reverse(),
	[(-16 + 62)] = string.char((-55 + 164), (21 + 84), (80 + 30)),
	[(-33 + 71)] = string.char((-10 + 86), (-78 + 189), (19 + 78), (85 + 15)) .. "\83\101\114\118" .. string.char(
		(45 + 56),
		(56 + 58),
		(-74 + 142)
	) .. "\97\116" .. "\97",
	[(60 + 1)] = (-17 + 96),
	[(81 + -66)] = ("\116\115"):reverse() .. ("\105\114"):reverse() .. string.char((5 + 105), (25 + 78)),
	[(2 + 31)] = nil,
	[(-26 + 75)] = "",
	[(92 + -29)] = (-32 + 38),
	[(-41 + 66)] = "\80\101\114\115\105\115" .. "\116\101" .. "\110\99" .. "\101",
	[(22 + -4)] = "\46",
	[(-58 + 88)] = "\83\97\118\101"
		.. string.char((12 + 71), (67 + 34), (-55 + 169), (14 + 104), (85 + 16))
		.. ("\116\97\68\114"):reverse()
		.. ("\97"):reverse(),
	[(30 + -23)] = "\98" .. ("\101\116\121"):reverse(),
	[(32 + -9)] = "\114\97\119" .. "\115" .. "\101\116",
	[(40 + -39)] = true,
	[(-18 + 59)] = "\67"
		.. "\114\101\97\116\76"
		.. ("\116\83\101\103\114\97"):reverse()
		.. ("\114"):reverse()
		.. ("\84\99\112\82"):reverse()
		.. ("\108\67\111"):reverse()
		.. "\105\101\110"
		.. ("\116"):reverse(),
	[(33 + -22)] = string.char((4 + 112), (22 + 89), (-82 + 197))
		.. ("\116"):reverse()
		.. "\114\105\110"
		.. string.char((-30 + 133)),
	[(-69 + 83)] = string.char((68 + 48), (-88 + 185)) .. "\98\108\101",
	[(-87 + 115)] = "\82\117\110\73\110\83"
		.. "\97\110\100\98"
		.. string.char((-27 + 138))
		.. string.char((-22 + 142), (-28 + 111), (96 + 1), (-4 + 106))
		.. "\101",
	[(35 + -13)] = ("\105\115\114\101\80"):reverse() .. string.char((3 + 112), (73 + 43)) .. "\101\110" .. "\99\101",
	[(-16 + 25)] = (-80 + 82),
	[(49 + -37)] = ("\116\97\109"):reverse() .. ("\104"):reverse(),
	[(17 + 3)] = false,
	[(78 + -76)] = false,
	[(75 + -13)] = (-84 + 161),
	[(44 + -23)] = false,
	[(-35 + 51)] = ("\58"):reverse(),
	[(88 + -69)] = "\116\97\98" .. "\108\101",
	[(-48 + 92)] = "",
	[(-33 + 70)] = ("\105\115\114\101\80"):reverse() .. ("\115"):reverse() .. "\116\101\110\99\101",
	[(-13 + 53)] = "\83\97\118\101"
		.. "\83\101\114\118"
		.. string.char((100 + 1), (-37 + 151), (47 + 21))
		.. string.char((-6 + 103), (-9 + 125), (-91 + 188)),
	[(-71 + 116)] = (27 + 973),
	[(-38 + 88)] = (14 + 84),
	[(82 + -35)] = "\105\110\115\101" .. string.char((87 + 27)) .. "\116",
	[(77 + -43)] = true,
	[(14 + 17)] = "\83\97\118\101\80"
		.. string.char((-53 + 154), (-45 + 159), (-68 + 183), (87 + 18), (29 + 86))
		.. "\116"
		.. string.char((-7 + 108), (49 + 61), (-21 + 137), (93 + -10), (-82 + 198))
		.. string.char((96 + 18), (56 + 49), (52 + 58))
		.. ("\103"):reverse(),
	[(-89 + 118)] = ("\105\115\114\101\80"):reverse() .. "\115\116" .. ("\101\99\110\101"):reverse(),
}
local qnw3f0xm = GLOBAL
function IsmodDownLoad(VQMNMl)
	if qnw3f0xm.KnownModIndex:IsModEnabledAny(VQMNMl) then
		return uVVtT7qK[(-94 + 95)]
	end
	return uVVtT7qK[(42 + -40)]
end
function SimpleHash(S1n2W_c)
	if S1n2W_c == uVVtT7qK[(-3 + 6)] then
		return
	end
	local f1cO1Qe = uVVtT7qK[(-14 + 18)]
	for i = uVVtT7qK[(-93 + 98)], #S1n2W_c do
		local VeBIODjp = qnw3f0xm[uVVtT7qK[(98 + -92)]][uVVtT7qK[(-33 + 40)]](S1n2W_c, i)
		f1cO1Qe = (f1cO1Qe * uVVtT7qK[(66 + -58)] + VeBIODjp) % uVVtT7qK[(95 + -86)] ^ uVVtT7qK[(7 + 3)]
	end
	return qnw3f0xm[uVVtT7qK[(66 + -55)]](qnw3f0xm[uVVtT7qK[(55 + -43)]][uVVtT7qK[(-52 + 65)]](f1cO1Qe))
end
function CheckTable(rtKkQQkt, WLLjTfmo, yL2GpTPU)
	if type(rtKkQQkt) ~= uVVtT7qK[(69 + -55)] then
		return
	end
	if type(WLLjTfmo) ~= uVVtT7qK[(49 + -34)] then
		return
	end
	local ng3dUKAI = WLLjTfmo:find(uVVtT7qK[(22 + -6)])
	local SYIsOtB
	for Sn92nAF, Fxdnj_ in ipairs(WLLjTfmo:split(uVVtT7qK[(87 + -70)])) do
		for Wd1MVw, wPWo1GHY in ipairs(Fxdnj_:split(uVVtT7qK[(-35 + 53)])) do
			if type(rtKkQQkt) ~= uVVtT7qK[(-14 + 33)] then
				return uVVtT7qK[(34 + -14)]
			end
			SYIsOtB = rtKkQQkt
			if rtKkQQkt == qnw3f0xm then
				rtKkQQkt = rtKkQQkt:rawget(wPWo1GHY)
			else
				rtKkQQkt = rtKkQQkt[wPWo1GHY]
			end
		end
	end
	if yL2GpTPU and type(rtKkQQkt) ~= yL2GpTPU then
		return uVVtT7qK[(98 + -77)]
	end
	if ng3dUKAI then
		return rtKkQQkt, rtKkQQkt and SYIsOtB
	else
		return rtKkQQkt
	end
end
env[uVVtT7qK[(34 + -12)]] = {}
qnw3f0xm[uVVtT7qK[(-20 + 43)]](qnw3f0xm, uVVtT7qK[(-67 + 91)], env[uVVtT7qK[(-13 + 38)]])
env[uVVtT7qK[(-73 + 99)]][uVVtT7qK[(-70 + 97)]] = function(HyXnzbK)
	local gRLUDKq = {}
	qnw3f0xm.TheSim:GetPersistentString(HyXnzbK, function(W2QgUM, kHcHNlGG)
		if W2QgUM then
			local DbFznNww, RVz5qBgQ = qnw3f0xm[uVVtT7qK[(-14 + 42)]](kHcHNlGG)
			if DbFznNww and RVz5qBgQ then
				gRLUDKq = RVz5qBgQ
			end
		end
	end)
	return gRLUDKq
end
env[uVVtT7qK[(-55 + 84)]][uVVtT7qK[(-40 + 70)]] = function(TzwWowFj, GkaHME5O)
	qnw3f0xm[uVVtT7qK[(-82 + 113)]](
		TzwWowFj,
		qnw3f0xm[uVVtT7qK[(30 + 2)]](GkaHME5O, uVVtT7qK[(87 + -54)], uVVtT7qK[(-36 + 70)])
	)
end
env[uVVtT7qK[(-93 + 128)]][uVVtT7qK[(100 + -64)]] = function(xVxEVZo5, Q3h_tu)
	local t3rJs9v7 = env[uVVtT7qK[(27 + 10)]][uVVtT7qK[(-28 + 66)]](xVxEVZo5)
	for yOTKf0, nP0uTif in pairs(Q3h_tu) do
		t3rJs9v7[yOTKf0] = nP0uTif
	end
	env[uVVtT7qK[(80 + -41)]][uVVtT7qK[(-63 + 103)]](xVxEVZo5, t3rJs9v7)
end
env[uVVtT7qK[(-76 + 117)]] = function(u7ccyujk, tkKFeOn, SoiEUvU)
	local Qhxsqk = {}
	local Dxtm34Zc = uVVtT7qK[(-26 + 68)]
	for i = uVVtT7qK[(74 + -69)], Dxtm34Zc - uVVtT7qK[(-25 + 30)] do
		AddClientModRPCHandler(u7ccyujk, tkKFeOn .. i, function(tnUfkf)
			Qhxsqk[i] = tnUfkf
		end)
	end
	AddClientModRPCHandler(u7ccyujk, tkKFeOn .. Dxtm34Zc, function(YTcshEe)
		qnw3f0xm.TheWorld:DoTaskInTime(uVVtT7qK[(15 + 28)], function(snDgzh4)
			Qhxsqk[Dxtm34Zc] = YTcshEe
			local tlGjTa = uVVtT7qK[(37 + 7)]
			for i = uVVtT7qK[(83 + -78)], Dxtm34Zc do
				tlGjTa = tlGjTa .. Qhxsqk[i]
			end
			SoiEUvU(tlGjTa)
		end)
	end)
	local function laMF82P(uPs2UZ, dAzUOCPz)
		local function qRHsIf8v(xV7UjGI, GPayTUBr)
			local EIJyyxf = {}
			GPayTUBr = GPayTUBr or uVVtT7qK[(-86 + 131)]
			local LKHTfNW = #xV7UjGI
			local IWYJRKi = uVVtT7qK[(42 + -37)]
			while IWYJRKi <= LKHTfNW do
				local Jmn0_9H4 = math[uVVtT7qK[(-63 + 109)]](IWYJRKi + GPayTUBr - uVVtT7qK[(-36 + 41)], LKHTfNW)
				table[uVVtT7qK[(41 + 6)]](EIJyyxf, xV7UjGI:sub(IWYJRKi, Jmn0_9H4))
				IWYJRKi = Jmn0_9H4 + uVVtT7qK[(-59 + 64)]
			end
			return EIJyyxf
		end
		local E0G4WPG4 = {}
		if dAzUOCPz then
			E0G4WPG4 = qRHsIf8v(dAzUOCPz, uVVtT7qK[(-34 + 82)])
		end
		for i = uVVtT7qK[(89 + -84)], Dxtm34Zc do
			SendModRPCToClient(GetClientModRPC(u7ccyujk, tkKFeOn .. i), uPs2UZ, E0G4WPG4[i] or uVVtT7qK[(99 + -50)])
		end
	end
	return laMF82P
end
